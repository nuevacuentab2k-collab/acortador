module.exports = {
  ...require("./domain.model"),
  ...require("./host.model"),
  ...require("./ip.model"),
  ...require("./link.model"),
  ...require("./user.model"),
  ...require("./visit.model"),
}
